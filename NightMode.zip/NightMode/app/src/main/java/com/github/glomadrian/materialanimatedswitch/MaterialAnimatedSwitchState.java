package com.github.glomadrian.materialanimatedswitch;

/**
 * @author Adrián García Lomas
 */
public enum MaterialAnimatedSwitchState {
  INIT, RELEASE, PRESS
}
