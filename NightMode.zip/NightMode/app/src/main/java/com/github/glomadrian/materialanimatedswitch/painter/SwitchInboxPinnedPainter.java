package com.github.glomadrian.materialanimatedswitch.painter;

import com.github.glomadrian.materialanimatedswitch.MaterialAnimatedSwitchState;

/**
 * @author Adrián García Lomas
 */
public interface SwitchInboxPinnedPainter extends Painter<MaterialAnimatedSwitchState> {
}
